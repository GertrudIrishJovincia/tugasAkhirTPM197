class AuthRoutes {
  static const getStarted = '/get-started';
  static const login = '/login';
}
