class DashboardRoutes {
  static const main = '/dashboard';
}
