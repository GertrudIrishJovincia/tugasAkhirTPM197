class Product {
  final String id;
  final String productName;
  final int productPrice;
  final String productImage;

  Product({
    required this.id,
    required this.productName,
    required this.productPrice,
    required this.productImage,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'].toString(), // pastikan String
      productName: json['product_name'] ?? 'Tanpa Nama',
      productPrice: json['product_price'] ?? 0,
      productImage: json['product_image'] ?? '',
    );
  }
}
